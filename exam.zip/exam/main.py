from typing import Annotated, Optional
from fastapi import FastAPI, Form
import datetime
from pydantic import BaseModel

class Order(BaseModel):
    number : int
    startDate : datetime.date
    deviceType : str
    model : str
    description : str
    fio : str
    phone : str
    status : str
    master : Optional[str] = 'Не установлен'

class UpdateOrderDTO(BaseModel):
    number: int
    status: Optional[str] = ""
    description: Optional[str] = ""
    master: Optional[str] = ""
    comment: Optional[str] = str

app = FastAPI()

repo = [

    Order(
        number = 1,
        startDate = '2001-12-12',
        deviceType = 'Офисный компьютер',
        model = 'Dexp',
        description = 'Черный экран при загрузке',
        fio = 'Губин Виктор Семенович',
        phone = '+79003339922',
        status = 'В процессе')
]

@app.get('/orders')
def get_orders():
    return repo

@app.get('/create')
def create_order(dto : Annotated[Order, Form()]):
    repo.append(dto)

@app.post('/update')
def update_orders(dto : Annotated[UpdateOrderDTO, Form()]):
    global message
    for o in repo:
        if o.number == dto.number:
            if dto.status != o.status and dto.status != '':
                o.status = dto.status
                message += f'Статус заявки {o.number} изменен\n'
                if(o.status == 'Завершена'):
                    message += f'Заявка {o.number} Завершена\n'
            if dto.description != '':
                o.description = dto.description
            if dto.master != '':
                o.master = dto.master
            return o
    return "Не найдено"
 #           if dto.comment != None and dto.comment != '':
#                o.comments.append(dto.comment)